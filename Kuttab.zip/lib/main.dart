import 'package:flutter/material.dart';

void main() {
  runApp(const KuttabApp());
}

class KuttabTheme {
  static const Color royalIndigo = Color(0xFF0F172A);
  static const Color tealEmerald = Color(0xFF0D9488);
  static const Color tealLight = Color(0xFF14B8A6);
  static const Color softGold = Color(0xFFF59E0B);
  static const Color dangerRed = Color(0xFFEF4444);
  static const Color bgCanvas = Color(0xFFF8FAFC);
  static const Color cardBg = Colors.white;

  static ThemeData get lightTheme {
    return ThemeData(
      scaffoldBackgroundColor: bgCanvas,
      primaryColor: tealEmerald,
      colorScheme: ColorScheme.fromSeed(
        seedColor: tealEmerald,
        primary: tealEmerald,
        secondary: softGold,
      ),
    );
  }
}

class KuttabApp extends StatelessWidget {
  const KuttabApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'كُتّاب - إدارة الفصل الذكية',
      debugShowCheckedModeBanner: false,
      theme: KuttabTheme.lightTheme,
      home: const MainNavigationWrapper(),
    );
  }
}

class MainNavigationWrapper extends StatefulWidget {
  const MainNavigationWrapper({Key? key}) : super(key: key);

  @override
  State<MainNavigationWrapper> createState() => _MainNavigationWrapperState();
}

class _MainNavigationWrapperState extends State<MainNavigationWrapper> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const TeacherDashboardScreen(),
    const BehaviorManagementScreen(),
    const ParentPortalScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(
          index: _currentIndex,
          children: _screens,
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          selectedItemColor: KuttabTheme.tealEmerald,
          unselectedItemColor: Colors.grey,
          showUnselectedLabels: true,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
                icon: Icon(Icons.dashboard_rounded), label: 'الرئيسية'),
            BottomNavigationBarItem(
                icon: Icon(Icons.stars_rounded), label: 'رصد السلوك'),
            BottomNavigationBarItem(
                icon: Icon(Icons.family_restroom_rounded), label: 'ولي الأمر'),
          ],
        ),
      ),
    );
  }
}

class TeacherDashboardScreen extends StatelessWidget {
  const TeacherDashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KuttabTheme.bgCanvas,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 22,
              backgroundColor: KuttabTheme.tealEmerald,
              child: Text('أ',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18)),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('مرحباً، أ. عبد الله 👋',
                    style: TextStyle(
                        color: KuttabTheme.royalIndigo,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
                Text('السبت، 10 أكتوبر 2026',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded,
                color: KuttabTheme.royalIndigo, size: 28),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCurrentClassCard(),
            const SizedBox(height: 24),
            const Text('الإجراءات السريعة',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: KuttabTheme.royalIndigo)),
            const SizedBox(height: 12),
            _buildQuickActionsGrid(),
            const SizedBox(height: 24),
            const Text('أبطال الفصل هذا الأسبوع 🏆',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: KuttabTheme.royalIndigo)),
            const SizedBox(height: 12),
            _buildTopStudentsList(),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentClassCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [KuttabTheme.royalIndigo, Color(0xFF1E293B)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: KuttabTheme.tealEmerald.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('الحصة الحالية',
                    style: TextStyle(
                        color: KuttabTheme.tealLight,
                        fontSize: 12,
                        fontWeight: FontWeight.bold)),
              ),
              const Text('⏱️ متبقي 20 دقيقة',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 12),
          const Text('الصف السادس (أ) • لغتي الجميلة',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('👥 الحضور: 24 / 26 طالب',
              style: TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: KuttabTheme.tealEmerald,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {},
                  icon: const Icon(Icons.check_circle_outline,
                      color: Colors.white, size: 18),
                  label: const Text('تحضير سريع',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(
                        color: KuttabTheme.softGold, width: 1.5),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {},
                  icon: const Icon(Icons.star_border,
                      color: KuttabTheme.softGold, size: 18),
                  label: const Text('رصد السلوك',
                      style: TextStyle(
                          color: KuttabTheme.softGold,
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildQuickActionsGrid() {
    return Row(
      children: [
        _buildActionButton(
            Icons.add_task_rounded, 'واجب جديد', KuttabTheme.tealEmerald),
        const SizedBox(width: 12),
        _buildActionButton(
            Icons.analytics_outlined, 'التقارير', KuttabTheme.royalIndigo),
        const SizedBox(width: 12),
        _buildActionButton(
            Icons.campaign_outlined, 'تنبيه للكل', KuttabTheme.softGold),
      ],
    );
  }

  Widget _buildActionButton(IconData icon, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: KuttabTheme.cardBg,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(0.1),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 8),
            Text(label,
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: KuttabTheme.royalIndigo)),
          ],
        ),
      ),
    );
  }

  Widget _buildTopStudentsList() {
    final students = [
      {'name': 'يزن العلي', 'points': '150 نقطة', 'badge': '🥇'},
      {'name': 'سارة أحمد', 'points': '135 نقطة', 'badge': '🥈'},
      {'name': 'عمر خالد', 'points': '120 نقطة', 'badge': '🥉'},
    ];

    return Column(
      children: students
          .map((s) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: KuttabTheme.cardBg,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Text(s['badge']!, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Text(s['name']!,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: KuttabTheme.royalIndigo)),
                    const Spacer(),
                    Text(s['points']!,
                        style: const TextStyle(
                            color: KuttabTheme.tealEmerald,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ))
          .toList(),
    );
  }
}

class BehaviorManagementScreen extends StatefulWidget {
  const BehaviorManagementScreen({Key? key}) : super(key: key);

  @override
  State<BehaviorManagementScreen> createState() =>
      _BehaviorManagementScreenState();
}

class _BehaviorManagementScreenState extends State<BehaviorManagementScreen> {
  final List<Map<String, dynamic>> students = [
    {'id': '1', 'name': 'يزن العلي', 'points': 150, 'avatar': '👦🏻'},
    {'id': '2', 'name': 'سارة أحمد', 'points': 135, 'avatar': '👧🏽'},
    {'id': '3', 'name': 'عمر خالد', 'points': 120, 'avatar': '👦🏼'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KuttabTheme.bgCanvas,
      appBar: AppBar(
        backgroundColor: KuttabTheme.royalIndigo,
        elevation: 0,
        title: const Text('إدارة السلوك • الصف السادس (أ)',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold)),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: students.length,
              itemBuilder: (context, index) {
                final student = students[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: KuttabTheme.cardBg,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Text(student['avatar'],
                          style: const TextStyle(fontSize: 32)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(student['name'],
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: KuttabTheme.royalIndigo)),
                            Text('${student['points']} نقطة',
                                style: const TextStyle(
                                    color: KuttabTheme.tealEmerald,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: KuttabTheme.tealEmerald),
                        onPressed: () {},
                        child: const Text('تقييم',
                            style: TextStyle(color: Colors.white)),
                      )
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ParentPortalScreen extends StatelessWidget {
  const ParentPortalScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KuttabTheme.bgCanvas,
      appBar: AppBar(
        backgroundColor: KuttabTheme.royalIndigo,
        title: const Text('بوابة ولي الأمر • متابعة يزن',
            style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                  color: KuttabTheme.cardBg,
                  borderRadius: BorderRadius.circular(20)),
              child: Row(
                children: const [
                  CircleAvatar(
                      radius: 28,
                      backgroundColor: KuttabTheme.tealEmerald,
                      child: Text('👦🏻', style: TextStyle(fontSize: 28))),
                  SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('يزن العلي',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: KuttabTheme.royalIndigo)),
                      Text('الصف السادس (أ)',
                          style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                  Spacer(),
                  Text('🏆 150 نقطة',
                      style: TextStyle(
                          color: KuttabTheme.softGold,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
